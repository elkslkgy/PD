#ifdef __GNUC__
# warning Gem/SynchedWorkerThread.h is deprecated - please include "Utils/SynchedWorkerThread.h" instead
#endif
#include "Utils/SynchedWorkerThread.h"
