#ifdef __GNUC__
# warning Gem/WorkerThread.h is deprecated - please include "Utils/WorkerThread.h" instead
#endif
#include "Utils/WorkerThread.h"
