#ifdef __GNUC__
# warning Gem/ThreadSemaphore.h is deprecated - please include "Utils/ThreadSemaphore.h" instead
#endif
#include "Utils/ThreadSemaphore.h"
