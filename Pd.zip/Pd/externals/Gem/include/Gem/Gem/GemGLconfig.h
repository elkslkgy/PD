/* src/Gem/GemGLconfig.h.  Generated from GemGLconfig.h.in by configure.  */

/* Define to 1 if Gem is built with multi-context support */
#define GEM_MULTICONTEXT 1

/* Define to 1 if using the built-in GLEW */
#define GLEW_BUILD 1
